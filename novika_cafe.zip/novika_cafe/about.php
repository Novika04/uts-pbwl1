<h2>Mengenai Junction Cafe</h2>

<div class="info" class="justify"><strong>Junction Cafe</strong> adalah kafe yangmenghidangkan makanan khas Indonesia dan juga makanan barat yang berkonsep sebagaitempat untuk bersantai bersama keluarga dan teman-teman serta sebagai tempat yang nyaman untuk mengerjakan tugas, belajar,atau rapat.</div>