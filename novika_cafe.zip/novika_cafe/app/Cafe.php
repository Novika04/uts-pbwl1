<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Cafe extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_minuman";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $minuman_nama = $_POST['minuman_nama'];
        $minuman_jenis = $_POST['minuman_jenis'];
        $harga = $_POST['harga'];

        $sql = "INSERT INTO tb_minuman (minuman_nama, minuman_jenis, harga) VALUES (:minuman_nama, :minuman_jenis, :harga)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":minuman_nama", $minuman_nama);
        $stmt->bindParam(":minuman_jenis", $minuman_jenis);
        $stmt->bindParam(":harga", $harga);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_minuman WHERE minuman_id=:minuman_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":minuman_id", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $minuman_nama = $_POST['minuman_nama'];
        $minuman_jenis = $_POST['minuman_jenis'];
        $harga = $_POST['harga'];
        $minuman_id = $_POST['minuman_id'];

        $sql = "UPDATE tb_minuman SET minuman_nama=:minuman_nama, minuman_jenis=:minuman_jenis, harga=:harga WHERE minuman_id=:minuman_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":minuman_nama", $minuman_nama);
        $stmt->bindParam(":minuman_jenis", $minuman_jenis);
        $stmt->bindParam(":harga", $harga);
        $stmt->bindParam(":minuman_id", $minuman_id);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_minuman WHERE minuman_id=:minuman_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":minuman_id", $id);
        $stmt->execute();

    }

}