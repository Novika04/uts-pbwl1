<?php

$cos = new App\Cafe;
$rows = $cos->tampil();

?>

<h2>Data Minuman</h2>

<table>
    <tr>
        <th>NO</th>
        <th>NAMA MINUMAN</th>
        <th>JENIS MINUMAN</th>
        <th>HARGA</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['minuman_id']; ?></td>
        <td><?php echo $row['minuman_nama']; ?></td>
        <td><?php echo $row['minuman_jenis']; ?></td>
        <td><?php echo $row['harga']; ?></td>
    </tr>
    <?php } ?>
</table>
