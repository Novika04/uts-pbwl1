<?php

$id = $_GET['id'];

$cos = new App\Cafe();
$rows = $cos->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?=cafe_tampil">Kembali</a>
</div>