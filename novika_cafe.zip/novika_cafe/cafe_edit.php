<?php

$id = $_GET['id'];
$cos = new App\Cafe();

$row = $cos->edit($id);
?>

<h2>Edit Data</h2>

<form action="cafe_proses.php" method="post">
    <input type="hidden" name="minuman_id" value="<?php echo $row['minuman_id']; ?>">
    <table>
        <tr>
            <td>NAMA MINUMAN</td>
            <td><input type="text" name="minuman_nama" value="<?php echo $row['minuman_nama']; ?>"></td>
        </tr>
        <tr>
            <td>JENIS MINUNAN</td>
            <td><input type="text" name="minuman_jenis" value="<?php echo $row['minuman_jenis']; ?>"></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="harga" value="<?php echo $row['harga']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>