<h2>Tambah Data</h2>

<form action="cafe_proses.php" method="post">
    <table>
        <tr>
            <td>NAMA MINUMAN</td>
            <td><input type="text" name="minuman_nama"></td>
        </tr>
        <tr>
            <td>JENIS MINUMAN</td>
            <td><input type="text" name="minuman_jenis"></td>
        </tr>
        <tr>
            <td>HARGA</td>
            <td><input type="text" name="harga"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>