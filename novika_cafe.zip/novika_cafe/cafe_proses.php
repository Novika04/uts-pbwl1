<?php

require_once "inc/Koneksi.php";
require_once "app/Cafe.php";

$cos = new App\Cafe();

if (isset($_POST['btn_simpan'])) {
    $cos->simpan();
    header("location:index.php?hal=cafe_tampil");
}

if (isset($_POST['btn_update'])) {
    $cos->update();
    header("location:index.php?hal=cafe_tampil");
}