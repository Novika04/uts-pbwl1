<?php

$cos = new App\Cafe;
$rows = $cos->tampil();

?>

<h2>Data Minuman</h2>

<a href="index.php?hal=cafe_input" class="btn">Tambah Data</a>

<table>
    <tr>
        <th>NO</th>
        <th>NAMA MINUMAN</th>
        <th>JENIS MINUMAN</th>
        <th>HARGA</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['minuman_id']; ?></td>
        <td><?php echo $row['minuman_nama']; ?></td>
        <td><?php echo $row['minuman_jenis']; ?></td>
        <td><?php echo $row['harga']; ?></td>
        <td><a href="index.php?hal=cafe_edit&id=<?php echo $row['minuman_id']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=cafe_delete&id=<?php echo $row['minuman_id']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
